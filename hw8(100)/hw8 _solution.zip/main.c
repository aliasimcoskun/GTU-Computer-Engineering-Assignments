#include <stdio.h>
#include <stdlib.h>
#include "util.h"


int main() {
    
	int *seq;
	int seqlen,xs;
	printf("Please enter the sequence length: ");
	scanf("%d", &seqlen);
	printf("Please enter the first element: ");
	scanf("%d", &xs);
	
	
	seq = malloc (seqlen*sizeof(int));
	int currentlen=0, i=0;
	generate_seq (xs, currentlen, seqlen, seq);
	
	
	// LOOP
	int *loop;
	loop = malloc ((seqlen/2)*sizeof(int));
	int looplen=seqlen/2, is_there_loop;
	
	// searching operation starts with loops with a length of seq's length / 2
	// looplen decrements itself within the function, until 2.
	check_loop_iterative(generate_seq, xs, seqlen, loop, &looplen); 
	if(looplen>0){
		printf("Loop: {");
		for (i = 0; i<looplen; i++)
			printf("%d, ",loop[i]);
		printf("\b\b}");
	}
	else // the function will return 0 if it can't find a loop
		printf("No loop found.");
		
		
	// HISTOGRAM	
	int h[9] = {0};
	
	// as in loop function, histogram calculatings start with digit 9
	hist_of_firstdigits(generate_seq, xs, seqlen, h, 9);
	printf("\n\nHistogram of the sequence: {");
	for (i=0; i<9;i++)
		printf("%d, ", h[i]);
	printf("\b\b}");
	return 0;
}
