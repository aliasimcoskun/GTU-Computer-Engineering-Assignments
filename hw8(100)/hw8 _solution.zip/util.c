#include <stdio.h>
#include <stdlib.h>
#include "util.h"


void generate_seq (int xs, int currentlen, int seqlen, int *seq){
	if (currentlen==seqlen)
		return;
	else{
		if (currentlen==0){ // first element should be the input given by user
			seq[currentlen] = xs;
			currentlen ++;
			generate_seq(xs, currentlen, seqlen, seq);
		}		
		else{ // other elements should be calculated by using the formulas
			int lastelement;
			lastelement = seq[currentlen-1];
			if (lastelement%2==0) // if even
				seq[currentlen] = lastelement/2;
			else // if odd
				seq[currentlen] = (lastelement*3)+1;
			currentlen ++;
			generate_seq(xs, currentlen, seqlen, seq);
		}
	}
}


// the function decrease looplen by 1, each time it is being called. so if looplen=1 the function should stop
void check_loop_iterative(void (*f)(int, int, int, int *), int xs, int seqlen, int *loop, int *looplen){
	if (*looplen == 1){ 
		*looplen = 0;
		return;
	}
		
	int *seq = malloc(seqlen*sizeof(int));
	f(xs, 0, seqlen, seq);
	int i;
	if (*looplen == seqlen/2){ // if we are calling the function for the first time
		printf("\nSequence: {"); // print sequence
		for (i=0; i<seqlen;i++)
			printf("%d, ", seq[i]);
		printf("\b\b}\n\n");
	}
	
	printf("Checking if there is a loop of length %d...\n", *looplen);
	int ls, le;
	int is_there_loop = has_loop(seq, seqlen, *looplen, &ls, &le); // is there a loop with a length of looplen?
	if (is_there_loop == 1){
		printf("\n\nLoop detected with a length of %d.", le-ls+1);
		printf("\nThe indexes of the loop's first occurance: %d (first digit), %d (last digit)\n", ls,le);
		for (i = ls; i<=le; i++)
			loop[i-ls] = seq[i];
		return;	
	}
	else{
		*looplen = (*looplen)-1;
		check_loop_iterative(generate_seq, xs, seqlen, loop, looplen); //if there is no loop, check if there is a shorter one
	}

}

// a helper function to check if the sequence (*seq) has a loop (*loop) 
// for example: *seq: 5,4,3,2,1,2,1, *loop: 4,3  it returns 0 (false)
// for example: *seq: 5,4,3,2,1,2,1, *loop: 2,1  it returns 1 (true)
int check_loop (int *loop, int *seq, int s, int e){ 
	int * loop2 = malloc((e-s)*sizeof(int));
	int i;
	for (i=0; i<e-s;i++)
		loop2[i] = seq[s+i];
	for (i=0; i<e-s;i++)
		if (loop[i] != loop2[i])
			return 0;
	return 1;
}

int has_loop(int *arr, int n, int looplen, int *ls, int *le){
	int i, j, k, isloop=1;
	int *loop = malloc(looplen*sizeof(int));
	
	// this function works as follows (for a sequence 1,2,3,1,2,1,2 assuming looplen=2
	// taking first 2 elements, checking if it repeats itself like 1,2,1,2,1,2 ... which is not correct
	// taking 2,3 to see if the array ends with 3,2,3,2...
	// taking 3,1 to see if the array ends with 3,1,3,1...
	// taking 1,2 to see if the array ends with 1,2,1,2 (correct)	
	for(j=0; j<n-looplen; j++){
		for (i=0; i<looplen; i++)
			loop[i] = arr[i+j]; //taking the elements (like 3,1 in the example above)
		for (i=looplen+j; i<n; i=i+looplen){ //checking if it repeats itself
			isloop = check_loop (loop, arr, i, i+looplen);
			if (isloop==0) // if not, continue with the next elements
				break;
		}
		if (isloop==1){ // if there is a loop, return its information
			*ls = j;
			*le = j+looplen-1;
			return 1;	
		}
	}
	return 0;
}

// basic helper function to find the first digit of an integer
int get_first_digit(int x){ 
	while (x>=10)
		x = x/10;
	return x;
}

// for example, if digit is 4, the function finds the number of elements starting with 4
// the function starts with 9 and call itself again by decrementing this number by 1 (9,8,7... till 0)
void hist_of_firstdigits(void (*f)(int, int, int, int *), int xs,  int seqlen, int *h, int digit){
	if (digit == 0)
		return;
	int *seq = malloc(seqlen*sizeof(int));
	f(xs, 0, seqlen, seq);
	int i, first_digit;
	for (i=0; i<seqlen;i++){
		first_digit = get_first_digit(seq[i]);
		if (first_digit==digit)
			h[digit-1] ++;
	}
	hist_of_firstdigits(f, xs, seqlen, h, digit-1);
}


